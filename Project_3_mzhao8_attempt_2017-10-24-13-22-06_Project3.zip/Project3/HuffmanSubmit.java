import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.PriorityQueue;

/**
 *
 * This file is the implementation of Huffman Compression, including
 * encoding and decoding functions. This can effectively decrease the
 * size of the software.
 * @author Zixu (Shawn) Chen
 * @version 1.1
 * @date 2017-11-15
 *
 */
public class HuffmanSubmit implements Huffman {

  public static void main(String[] args) {
    //Testing
    Huffman huffman = new HuffmanSubmit();
    huffman.encode("alice30.txt", "EncodeOutput.txt", "Frequency.txt");
    huffman.decode("EncodeOutput.txt", "DecodeOutput.txt", "Frequency.txt");
    huffman.encode("ur.jpg", "ur.enc", "Frequency.txt");
    huffman.decode("ur.enc", "ur_dec.jpg", "Frequency.txt");
  }

  /**
   *
   * @param inputFile The name of the input file to be encoded.
   *          Do not modify this file.
   *
   * @param outputFile The name of the output file  (after encoding)
   *                This would be a binary file.
   *                If the file already exists, overwrite it.
   *
   * @param freqFile  Stores the frequency of each byte
   *          This file is a text file
   *          where each row contains texual representation
   *          of each byte and the  number of occurence of this byte
   *          separated by ':'
   *          An example entry would look like:
   *          01100001:12345
   *          Which means
   *          the letter a (ascii code 097, binary representation 01100001)
   *          has occureed 12345. This file does not need to be sorted.
   *          If this file already exists, overwrite.
   */
  @Override
  public void encode(String inputFile, String outputFile, String freqFile) {
    String[] codes = new String[256];
    getCharCodes(constructTree(getAndWriteFrequency(inputFile, freqFile)), codes, "");
    writeIntoOutputFile(inputFile, outputFile, codes);
    System.out.println("Huffman encoding complete!");
  }

  /**
   *
   * @param inputFile The name of the input file to be decoded.
   *     Do not modify this file.
   *
   * @param outputFile The name of the output file  (after decoding)
   *
   * @param freqFile  freqFile produced after encoding.
   *     Do not modify this file.
   */
  @Override
  public void decode(String inputFile, String outputFile, String freqFile) {
    BinaryIn in = new BinaryIn(inputFile);
    BinaryOut out = new BinaryOut(outputFile);

    Node root = constructTree(getFrequencyFromFile(freqFile));
    Node node = root;
    while (!in.isEmpty()) {
      boolean b = in.readBoolean();
      if (node.left == null && node.right == null) {
        out.write(node.character);
        node = root;
      }
      if (!b) {
        node = node.left;
      }
      else {
        node = node.right;
      }
    }
    out.flush();
    out.close();
    System.out.println("Successfully decode " + inputFile + " into " + outputFile + "!");
    System.out.println("Huffman decoding complete!");
  }

  /**
   * Get the frequency of characters in the input file and write them into the frequency file
   *
   * @param inputFile name of the input file
   * @param freqFile name of the frequency file
   * @return an array contains frequency of each ASCII characters
   */
  private static int[] getAndWriteFrequency(String inputFile, String freqFile) {
    HashMap<Character, Integer> map = new HashMap<>(256);

    //Get characters from input file and put them into a HashMap
    BinaryIn in = new BinaryIn(inputFile);
    while (!in.isEmpty()) {
      char c = in.readChar();
      map.put(c, map.containsKey(c) ? map.get(c) + 1 : 1);
    }

    //ASCII has a total of 256 kinds of codes
    int[] asciiFreq = new int[256];

    //Write the frequency into the freqFile and record them in an array
    try {
      BufferedWriter writer = new BufferedWriter(new FileWriter(freqFile));
      for (char c : map.keySet()) {
        asciiFreq[c] = map.get(c);
        writer.write(toBinary((int) c) + ":" + map.get(c));
        writer.newLine();
      }
      writer.flush();
      writer.close();
    } catch (IOException e) {
      System.out.println(e);
    }
    System.out.println("Successfully write frequency data into " + freqFile + "!");
    return asciiFreq;
  }

  /**
   * Generate an array that contains frequency information from frequency file
   * @param freqFile the name of the frequency file
   * @return the array that contains frequency information
   */
  private static int[] getFrequencyFromFile(String freqFile) {
    int[] frequency = new int[256];
    try {
      BufferedReader bReader = new BufferedReader(new FileReader(freqFile));
      String currentLine;
      String[] temp;
      while ((currentLine = bReader.readLine()) != null) {
        temp = currentLine.split(":");
        Integer decimal = Integer.parseInt(temp[0], 2);
        frequency[decimal] = Integer.parseInt(temp[1]);
      }
    } catch(IOException e) {
      System.out.println(e);
    }
    return frequency;
  }

  /**
   * Constuct the tree for Huffman Compression
   *
   * @param frequency an array contains the frequencies of all the ASCII characters
   * @return the root node of the tree constructed
   */
  private Node constructTree(int[] frequency) {
    PriorityQueue<Node> pQueue = new PriorityQueue<>();

    //Create nodes for characters that show up and put them into a priority queue
    for (char c = 0; c < frequency.length; c++) {
      if (frequency[c] > 0) {
        pQueue.offer(new Node(c, frequency[c]));
      }
    }

    //Construct the tree
    while (pQueue.size() > 1) {
      Node child1 = pQueue.poll();
      Node child2 = pQueue.poll();
      Node parent = new Node(child1, child2, '\0', child1.frequency + child2.frequency);
      pQueue.offer(parent);
    }
    return pQueue.poll();
  }

  /**
   * Get the codes for each node in the tree
   *
   * @param root the root of the tree
   * @param codes the String array that stores the codes for each character
   * @param path the path (essentially the code) from the root to a node
   */
  private static void getCharCodes(Node root, String[] codes, String path) {
    if (root.left == null && root.right == null) {
      codes[root.character] = path;
      return;
    }
    getCharCodes(root.left, codes, path + "0");
    getCharCodes(root.right, codes, path + "1");
  }

  /**
   * Write the output codes into the output file
   *
   * @param inputFile name of the input file
   * @param outputFile name of the output file
   * @param codes the array that contains the codes for each character
   */
  private static void writeIntoOutputFile(String inputFile, String outputFile, String[] codes) {
    BinaryIn in = new BinaryIn(inputFile);
    BinaryOut out = new BinaryOut(outputFile);
    while (!in.isEmpty()) {
      char c = in.readChar();
      for (int i = 0; i < codes[c].length(); i++) {
        out.write(codes[c].charAt(i) == '1');
      }
    }
    out.flush();
    out.close();
    System.out.println("Successfully write output data into " + outputFile + "!");
  }

  /**
   * Change the input from decimal form to binary form
   *
   * @param num the input number
   * @return binary form of the number
   */
  private static String toBinary(int num) {
    if (num == 0) {
      return "0";
    }
    if (num == 1) {
      return "1";
    }
    return toBinary(num / 2) + num % 2;
  }

  /**
   * Create the node class for the nodes in the tree
   */
  private static class Node implements Comparable<Node> {

    Node left;
    Node right;
    char character;
    int frequency;

    public Node(Node left, Node right, char character, int frequency) {
      this.left = left;
      this.right = right;
      this.character = character;
      this.frequency = frequency;
    }

    public Node(char character, int frequency) {
      this.left = null;
      this.right = null;
      this.character = character;
      this.frequency = frequency;
    }

    public Node() {
      this.left = null;
      this.right = null;
      this.character = '\0';
      this.frequency = 0;
    }

    //Allow compare by frequency
    @Override
    public int compareTo(Node o) {
      return this.frequency - o.frequency;
    }
  }
}
