// Import any package as required
import java.util.*;
import java.lang.Object.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class HuffmanSubmit implements Huffman {


  public  class Node implements Comparable<Node> {
     public final Character c;
     public final int freq;
     public final Node left, right;

     Node(char c, int freq, Node left, Node right) {
        this.c    = c;
        this.freq  = freq;
        this.left  = left;
        this.right = right;
     }

     Node(Map.Entry<Character,Integer> entry) {

        this.c = entry.getKey();
        this.freq = entry.getValue();
        this.left = null;
        this.right = null;
     }

     Node (Node left, Node right) {
        this.c = null;
        this.freq = left.freq + right.freq;
        this.left = left;
        this.right = right;
     }

     // is the node a leaf node?
     private boolean isLeaf() {
        assert ((left == null) && (right == null)) || ((left != null) && (right != null));
        return (left == null) && (right == null);
     }

     public String toString() {
        return this.c + ": " + this.freq;
     }
     // compare, based on frequency
     public int compareTo(Node that) {
        return this.freq - that.freq;
     }
  }

  private Node buildTree(HashMap<Character, Integer> hm) {

     PriorityQueue<Node> pq = new PriorityQueue<>();
     for (Map.Entry<Character,Integer> entry : hm.entrySet())
     {
        pq.offer(new Node(entry));
     }
     Iterator it = pq.iterator();


     while (pq.size() > 1) {
        Node left = pq.poll();
        Node right = pq.poll();

        pq.offer(new Node(left,right));
     }
     Node root = pq.poll();  // Root of the tree
     return root;
  }
  public void encode(String inputFile, String outputFile, String freqFile){

     BinaryIn  in  = new BinaryIn(inputFile);
     BinaryOut out = new BinaryOut(outputFile);
     BinaryOut freq = new BinaryOut(freqFile);


     HashMap<Character, Integer>  hm = new HashMap<>();
     HashMap<Character, String>  hm_code = new HashMap<>();
     List<Character> fileChar = new LinkedList<>();

     while (!in.isEmpty()) {
        char c = in.readChar();
        fileChar.add(c);
        int count = hm.containsKey(c) ? hm.get(c) : 0;
        hm.put(c, count + 1);
     }



     for (Map.Entry<Character,Integer> entry : hm.entrySet())
     {
        String str = Integer.toBinaryString(entry.getKey());
        str = String.format("%8s", str).replace(' ', '0');
        String entryStr = str + ":" + entry.getValue();
        freq.write(entryStr+"\n");
     }
     freq.flush(); // Must for writing file

     Node root = buildTree(hm);
     String beginCode = "";
     buildCodeHashMap(root,hm_code, beginCode);

     // Time to use this code to write output file

     ListIterator<Character>  itr = fileChar.listIterator();
     while(itr.hasNext()){
        char c = itr.next();
        String code = hm_code.get(c);

        for (int j = 0; j < code.length(); j++) {
           if (code.charAt(j) == '0') {
              out.write(false);
           }
           else if (code.charAt(j) == '1') {
              out.write(true);
           }
           else throw new IllegalStateException("Illegal code");
        }
     }
     out.flush();


  }



  private static void buildCodeHashMap(Node root, HashMap<Character, String> hm, String codeString){

     if (!root.isLeaf()) {
        buildCodeHashMap(root.left, hm,  codeString + '0');
        buildCodeHashMap(root.right, hm, codeString + '1');
     }
     else {
        // Child. So, contains Char/Byte for which we will have code
        hm.put(root.c, codeString);
     }
  }


  public void decode(String inputFile, String outputFile, String freqFile){


     BinaryIn  in  = new BinaryIn(inputFile);
     BinaryOut out = new BinaryOut(outputFile);

  HashMap<Character, Integer>  hm = new HashMap<>();

  try (BufferedReader br = new BufferedReader(new FileReader(freqFile))) {
        String line;
        while ((line = br.readLine()) != null) {
           String kv[] = line.split(":");
           String k = kv[0];
           String v = kv[1];

   char c = (char)Integer.parseInt(k, 2);
   int freq =Integer.parseInt(v);
   hm.put(c, freq);
     }



           // process the line.
        }
     catch (Exception e)
     {
        System.err.println(e.getMessage()); // handle exception
     }

  // Construct the tree
     Node root = buildTree(hm);

  // Read decoding starts now
  List <Boolean> b_list = new LinkedList<>();
  while (!in.isEmpty()) {
        boolean b = in.readBoolean();
    b_list.add(b);
  }


     Node x = root;
  for (int i = 0; i < b_list.size(); i++) {
           if (!x.isLeaf()) {
              if (b_list.get(i))
                 x =  x.right;
              else
                 x =  x.left;
           }
           else {
           out.write((char)x.c);
           x = root;
           i--; // Very important.
        // We are at leaf. So, don't waste a bit here
           }
       }
       out.flush();
  }

   public static void main(String[] args) {
      Huffman  huffman = new HuffmanSubmit();
		huffman.encode("ur.jpg", "ur.enc", "freq.txt");
		huffman.decode("ur.enc", "ur_dec.jpg", "freq.txt");
		// After decoding, both ur.jpg and ur_dec.jpg should be the same.
		// On linux and mac, you can use `diff' command to check if they are the same.
   }

}
