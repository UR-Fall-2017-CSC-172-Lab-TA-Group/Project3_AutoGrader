//author: Zhengdong Chen
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Set;

public class HuffmanSubmit implements Huffman
{
	public class Node
	{
		public char c;
		public boolean[] bin_ori,bin_mod;
		public int freq;
		public Node b0=null,b1=null;
		Node(){}
		Node(int frequency,Node branch0,Node branch1)
			{freq=frequency;b0=branch0;b1=branch1;}
		Node(char character,boolean[] bin_rep_o,int frequency)
			{c=character;bin_ori=bin_rep_o;freq=frequency;}
	}
	public void encode(String inputFile,String outputFile,String freqFile)
	{
		freqFile_gen(inputFile,freqFile);
		Node root=build_tree(freqFile);
		HashMap<Character,Node> encodeMap=mapping_gen(root,new HashMap<Character,Node>());
		BinaryIn input=new BinaryIn(inputFile);///
		BinaryOut output=new BinaryOut(outputFile);///
		while(!input.isEmpty())
			wrtBArr(encodeMap.get(input.readChar()).bin_mod,output);
		output.close();
	}
	public void decode(String inputFile,String outputFile,String freqFile)
	{
		Node root=build_tree(freqFile),trav=root;
		BinaryIn input=new BinaryIn(inputFile);///
		BinaryOut output=new BinaryOut(outputFile);///
		while(!input.isEmpty())
		{
			if(input.readBoolean())
				trav=trav.b1;
			else
				trav=trav.b0;
			if(trav.b0==null)
			{
				output.write(trav.c);
				trav=root;
			}
		}
		output.close();
	}
	private static void freqFile_gen(String inputFile,String freqFile)
	{
		BinaryIn input=new BinaryIn(inputFile);///
		HashMap<Character,Integer> freqList=new HashMap<>();
		while(!input.isEmpty())
		{
			char c=input.readChar();
			freqList.put(c,freqList.getOrDefault(c,0)+1);
		}
		PrintWriter freqOut=null;///
		try{freqOut=new PrintWriter(freqFile);}
		catch(FileNotFoundException e){e.printStackTrace();}
		Set<Map.Entry<Character,Integer>> entSet=freqList.entrySet();
		for(Map.Entry<Character,Integer> x:entSet)
		{
			boolean[] bArr=to_bArr(x.getKey());
			for(boolean bEle:bArr)
				freqOut.print(bEle?"1":"0");
			freqOut.println(":"+x.getValue());
			freqOut.flush();
		}
		freqOut.close();
	}
	private static Node build_tree(String freqFile)
	{
		Scanner freq=null;///
		try{freq=new Scanner(new File(freqFile));}
		catch(FileNotFoundException e){e.printStackTrace();}
		PriorityQueue<Node> pQueue=new PriorityQueue<>(128,new Comparator<Node>()
		{
			public int compare(Node n1,Node n2)
				{return n1.freq-n2.freq;}
		});
		while(freq.hasNext())
		{
			String temp=freq.next();
			boolean[] bb=new boolean[8];
			for(int i=0;i<8;i++)
				bb[i]=temp.charAt(i)!='0';
			pQueue.offer((new HuffmanSubmit()).new Node(to_char(bb),bb,Integer.parseInt(temp.substring(9))));
		}
		freq.close();
		while(true)
		{
			Node n1=pQueue.poll(),n2;
			if((n2=pQueue.poll())==null)
				return label_tree(n1,new LinkedList<Boolean>());
			pQueue.offer((new HuffmanSubmit()).new Node(n1.freq+n2.freq,n1,n2));
		}
	}
	private static Node label_tree(Node root,LinkedList<Boolean> bb)
	{
		if(root.b0==null)
		{
			root.bin_mod=new boolean[bb.size()];
			Iterator<Boolean> k=bb.iterator();
			for(int i=0;i<bb.size();i++)
				root.bin_mod[i]=(boolean)k.next();
			return root;
		}
		bb.addLast(new Boolean(false));
		label_tree(root.b0,bb);
		bb.removeLast();
		bb.addLast(new Boolean(true));
		label_tree(root.b1,bb);
		bb.removeLast();
		return root;
	}
	private static HashMap<Character,Node> mapping_gen(Node root,HashMap<Character,Node> hMap)
	{
		if(root.b0==null)
		{
			hMap.put(root.c,root);
			return hMap;
		}
		mapping_gen(root.b0,hMap);
		mapping_gen(root.b1,hMap);
		return hMap;
	}
	private static boolean[] to_bArr(char x)
	{
		boolean[] array=new boolean[8];
		for(int i=7;i>=0;i--,x>>=1)
			array[i]=(x&1)==1;
		return array;
	}
	private static char to_char(boolean[] a)
	{
		if(a==null||a.length<=0) return 0;
		char b=0;
		for(int i=0;i<8;i++)
			if(a[i])
				b|=(1<<(7-i));
		return b;
	}
	private static void wrtBArr(boolean[] bArr,BinaryOut file)
	{
		for(boolean bEle:bArr)
			file.write(bEle);
	}
	public static void main(String[] args)
	{
		Huffman huffman=new HuffmanSubmit();
		huffman.encode("src//Project3//alice30.txt","src//Project3//ur.enc","src//Project3//freq.txt");
		huffman.decode("src//Project3//ur.enc","src//Project3//ur_dec.txt","src//Project3//freq.txt");
		// After decoding, both ur.jpg and ur_dec.jpg should be the same.
		// On linux and mac, you can use `diff' command to check if they are the same.
	}
}
