Project 3
Name: Zixu (Shawn) Chen
URID: 29879847

This project is the implementation of Huffman Coding.